// 保存选项到 chrome.storage
function save_options() {
  const rpcUrl = document.getElementById('rpc-url').value;
  const rpcSecret = document.getElementById('rpc-secret').value;

  chrome.storage.sync.set({
    rpcUrl: rpcUrl,
    rpcSecret: rpcSecret
  }, () => {
    // 更新状态消息，告知用户选项已保存
    const status = document.getElementById('status');
    status.textContent = '设置已保存。';
    setTimeout(() => {
      status.textContent = '';
    }, 1500);
  });
}

// 从 chrome.storage 加载已保存的选项
function restore_options() {
  chrome.storage.sync.get({
    rpcUrl: 'http://127.0.0.1:6800/jsonrpc',
    rpcSecret: ''
  }, (items) => {
    document.getElementById('rpc-url').value = items.rpcUrl;
    document.getElementById('rpc-secret').value = items.rpcSecret;
  });
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options);
document.addEventListener('DOMContentLoaded', () => {
    const toggleSwitch = document.getElementById('toggleSwitch');
    const statusText = document.getElementById('statusText');
    const optionsLink = document.getElementById('openOptionsPage'); // 获取设置链接元素

    // 更新UI显示
    function updateUI(isEnabled) {
        toggleSwitch.checked = isEnabled;
        if (isEnabled) {
            statusText.textContent = '已启用';
            statusText.style.color = '#2196F3';
        } else {
            statusText.textContent = '已禁用';
            statusText.style.color = '#777';
        }
    }

    // 启动时，从存储中加载当前状态
    chrome.storage.sync.get('isEnabled', (data) => {
        updateUI(data.isEnabled);
    });

    // 当用户点击开关时，保存新状态
    toggleSwitch.addEventListener('change', () => {
        const isEnabled = toggleSwitch.checked;
        chrome.storage.sync.set({ isEnabled: isEnabled }, () => {
            updateUI(isEnabled);
        });
    });

    // --- 新增的逻辑 ---
    // 当用户点击设置图标时
    optionsLink.addEventListener('click', (e) => {
        e.preventDefault(); // 阻止 <a> 标签的默认跳转行为
        // 调用 Chrome API 打开扩展的选项页面
        chrome.runtime.openOptionsPage();
    });
});